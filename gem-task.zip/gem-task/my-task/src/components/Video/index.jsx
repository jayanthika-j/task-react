import React, { useState, useEffect } from 'react';
import instapractLogo from '../../assets/images/logo.png';
import userImage from '../../assets/images/user.png';
import './style.css';
import { useNavigate, useParams, useLocation } from 'react-router-dom';

const VideoConsultation = ({ user, onLogout }) => {
  const [permissions, setPermissions] = useState({
    network: false,
    camera: false,
    microphone: false,
    speaker: false
  });

  const navigate = useNavigate();
  const { doctorId } = useParams();
  const [selectedDoctor, setSelectedDoctor] = useState(null);
  const location = useLocation();
  const doctorData = location.state || {};

  useEffect(() => {
    // Fetch doctor details using doctorId
    const fetchDoctorDetails = async () => {
      try {
        const response = await fetch(`/api/doctors/${doctorId}`);
        const data = await response.json();
        setSelectedDoctor(data);
      } catch (error) {
        console.error('Error fetching doctor details:', error);
      }
    };

    fetchDoctorDetails();
  }, [doctorId]);

  const handleContinue = () => {
    navigate('/video-call', { 
      state: { 
        doctor: {
          name: doctorData.doctorName,
          image: doctorData.doctorImage,
          id: doctorData.doctorId,
          lastSeen: doctorData.lastSeen
        }
      }
    });
  };

  return (
    <div className="video-page">
      <nav className="nav-bar">
        <div className="nav-content">
          <div className="nav-left">
            <img src={instapractLogo} alt="InstaPract" className="nav-logo" />
          </div>
          <div className="nav-right">
            <div className="user-info">
              <div className="user-avatar">
                <img 
                  src={user?.PatientProfile?.profile_picture || userImage} 
                  alt="User"
                  onError={(e) => {
                    e.target.src = userImage; // Fallback to default image
                  }}
                />
              </div>
              <div className="user-details">
                <span className="user-name">
                  Hi, {user?.username?.split('@')[0] || 'User'}
                </span>
                <span className="user-id">
                  User ID: {user?.id || 'User'}
                </span>
              </div>
              <button className="logout-btn" onClick={onLogout}>
                <svg 
                  xmlns="http://www.w3.org/2000/svg" 
                  viewBox="0 0 24 24" 
                  fill="none" 
                  stroke="currentColor" 
                  strokeWidth="2" 
                  strokeLinecap="round" 
                  strokeLinejoin="round"
                >
                  <path d="M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4"></path>
                  <polyline points="10 17 15 12 10 7"></polyline>
                  <line x1="15" y1="12" x2="3" y2="12"></line>
                </svg>
              </button>
            </div>
          </div>
        </div>
      </nav>

      <main className="consultation-content">
        <h1>Video Consultation</h1>
        
        <div className="video-container">
          <div className="video-frame"></div>
        </div>

        <div className="permissions-section">
          <p className="permission-title">Please wait while we check your camera</p>
          
          <div className="permissions-grid">
            <div className={`permission-item ${permissions.network ? 'checked' : ''}`}>
              <svg viewBox="0 0 24 24" className="permission-icon">
                <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8z"/>
              </svg>
              <span>Network</span>
              <span className="check-icon">✓</span>
            </div>
            
            <div className={`permission-item ${permissions.camera ? 'checked' : ''}`}>
              <svg viewBox="0 0 24 24" className="permission-icon">
                <path d="M17 10.5V7c0-.55-.45-1-1-1H4c-.55 0-1 .45-1 1v10c0 .55.45 1 1 1h12c.55 0 1-.45 1-1v-3.5l4 4v-11l-4 4z"/>
              </svg>
              <span>Camera</span>
              <span className="check-icon">✓</span>
            </div>
            
            <div className={`permission-item ${permissions.microphone ? 'checked' : ''}`}>
              <svg viewBox="0 0 24 24" className="permission-icon">
                <path d="M12 14c1.66 0 3-1.34 3-3V5c0-1.66-1.34-3-3-3S9 3.34 9 5v6c0 1.66 1.34 3 3 3z"/>
                <path d="M17 11c0 2.76-2.24 5-5 5s-5-2.24-5-5H5c0 3.53 2.61 6.43 6 6.92V21h2v-3.08c3.39-.49 6-3.39 6-6.92h-2z"/>
              </svg>
              <span>Microphone</span>
              <span className="check-icon">✓</span>
            </div>
            
            <div className={`permission-item ${permissions.speaker ? 'checked' : ''}`}>
              <svg viewBox="0 0 24 24" className="permission-icon">
                <path d="M3 9v6h4l5 5V4L7 9H3zm13.5 3c0-1.77-1.02-3.29-2.5-4.03v8.05c1.48-.73 2.5-2.25 2.5-4.02zM14 3.23v2.06c2.89.86 5 3.54 5 6.71s-2.11 5.85-5 6.71v2.06c4.01-.91 7-4.49 7-8.77s-2.99-7.86-7-8.77z"/>
              </svg>
              <span>Speaker</span>
              <span className="check-icon">✓</span>
            </div>
          </div>

          <p className="browser-support">
            Supported web browsers for this video consultation technology include the latest versions of Chrome, Firefox, Safari, and Edge.
          </p>

          <button 
            className="continue-btn"
            onClick={handleContinue}
          >
            Continue
          </button>
        </div>
      </main>
    </div>
  );
};

export default VideoConsultation; 