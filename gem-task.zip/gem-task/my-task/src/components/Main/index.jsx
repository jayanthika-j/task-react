import React from 'react';
import './style.css';

const SplitScreen = ({ leftContent, rightContent }) => {
  return (
    <div className="split-container">
      <div className="left-panel">
        {leftContent}
      </div>
      <div className="right-panel">
        {rightContent}
      </div>
    </div>
  );
};

export default SplitScreen; 