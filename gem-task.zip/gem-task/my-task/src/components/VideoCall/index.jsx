import React, { useState } from 'react';
import instapractLogo from '../../assets/images/logo.png';
import userImage from '../../assets/images/user.png';
import doctorImage from '../../assets/images/doctor.png';
import './style.css';
import { useLocation } from 'react-router-dom';

const VideoCall = ({ user, onLogout }) => {
  const location = useLocation();
  console.log('Location state in VideoCall:', location.state); // For debugging

  const doctor = location.state?.doctor || {
    name: 'Doctor',
    lastSeen: '5 hours ago',
    image: doctorImage // fallback image
  };

  console.log('Doctor data in VideoCall:', doctor); // For debugging

  const [isMuted, setIsMuted] = useState(false);
  const [isVideoOff, setIsVideoOff] = useState(false);
  const [message, setMessage] = useState('');
  const [messages, setMessages] = useState([
    {
      text: `Hi ${doctor.name}, this is the message from the patient explaining their problem.`,
      sender: "patient"
    },
    {
      text: "Hi Patient, this is the message from the doctor to the patient.",
      sender: "doctor"
    }
  ]);

  const handleSendMessage = (e) => {
    e.preventDefault();
    if (message.trim()) {
      setMessages([...messages, { text: message, sender: 'patient' }]);
      setMessage('');
    }
  };

  return (
    <div className="video-call-page">
      <nav className="nav-bar">
        <div className="nav-content">
          <div className="nav-left">
            <img src={instapractLogo} alt="InstaPract" className="nav-logo" />
          </div>
          <div className="nav-right">
            <div className="user-info">
              <div className="user-avatar">
                <img 
                  src={user?.PatientProfile?.profile_picture || userImage} 
                  alt="User"
                  onError={(e) => {
                    e.target.src = userImage;
                  }}
                />
              </div>
              <div className="user-details">
                <span className="user-name">
                  Hi, {user?.username?.split('@')[0] || 'User'}
                </span>
                <span className="user-id">
                  User ID: {user?.id || 'User'}
                </span>
              </div>
              <button className="logout-btn" onClick={onLogout}>
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <path d="M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4"></path>
                  <polyline points="10 17 15 12 10 7"></polyline>
                  <line x1="15" y1="12" x2="3" y2="12"></line>
                </svg>
              </button>
            </div>
          </div>
        </div>
      </nav>

      <div className="video-chat-container">
        <div className="video-section">
          <div className="main-video">
            <img src={doctor.image || doctorImage} alt="Doctor" className="doctor-stream" />
            <div className="video-overlay">
              <div className="participant-info">
                <img 
                  src={doctor.image || doctorImage} 
                  alt={doctor.name} 
                  className="participant-avatar" 
                />
                <span className="participant-name">{doctor.name}</span>
                <span className="call-duration">10:58</span>
              </div>
            </div>
          </div>
          <div className="self-video">
            <img src={userImage} alt="You" className="patient-stream" />
            <div className="video-overlay">
              <div className="participant-info">
                <span className="participant-name">You</span>
              </div>
            </div>
          </div>

          <div className="video-controls">
            <button 
              className={`control-btn ${isMuted ? 'active' : ''}`}
              onClick={() => setIsMuted(!isMuted)}
            >
              <svg viewBox="0 0 24 24">
                <path d={isMuted ? 
                  "M19 11h-1.7c0 .74-.16 1.43-.43 2.05l1.23 1.23c.56-.98.9-2.09.9-3.28zm-4.02.17c0-.06.02-.11.02-.17V5c0-1.66-1.34-3-3-3S9 3.34 9 5v.18l5.98 5.99zM4.27 3L3 4.27l6.01 6.01V11c0 1.66 1.33 3 2.99 3 .22 0 .44-.03.65-.08l1.66 1.66c-.71.33-1.5.52-2.31.52-2.76 0-5.3-2.1-5.3-5.1H5c0 3.41 2.72 6.23 6 6.72V21h2v-3.28c.91-.13 1.77-.45 2.54-.9l4.19 4.18L21 20.73 4.27 3z" :
                  "M12 14c1.66 0 3-1.34 3-3V5c0-1.66-1.34-3-3-3S9 3.34 9 5v6c0 1.66 1.34 3 3 3z"
                }/>
              </svg>
            </button>

            <button 
              className={`control-btn ${isVideoOff ? 'active' : ''}`}
              onClick={() => setIsVideoOff(!isVideoOff)}
            >
              <svg viewBox="0 0 24 24">
                <path d="M17 10.5V7c0-.55-.45-1-1-1H4c-.55 0-1 .45-1 1v10c0 .55.45 1 1 1h12c.55 0 1-.45 1-1v-3.5l4 4v-11l-4 4z"/>
              </svg>
            </button>

            <button className="control-btn end-call">
              <svg viewBox="0 0 24 24">
                <path d="M12 9c-1.6 0-3.15.25-4.6.72v3.1c0 .39-.23.74-.56.9-.98.49-1.87 1.12-2.66 1.85-.18.18-.43.28-.7.28-.28 0-.53-.11-.71-.29L.29 13.08c-.18-.17-.29-.42-.29-.7 0-.28.11-.53.29-.71C3.34 8.78 7.46 7 12 7s8.66 1.78 11.71 4.67c.18.18.29.43.29.71 0 .28-.11.53-.29.71l-2.48 2.48c-.18.18-.43.29-.71.29-.27 0-.52-.11-.7-.28-.79-.74-1.68-1.36-2.66-1.85-.33-.16-.56-.5-.56-.9v-3.1C15.15 9.25 13.6 9 12 9z"/>
              </svg>
            </button>
          </div>
        </div>

        <div className="chat-section">
          <div className="chat-header">
            <img 
              src={doctor.image || doctorImage} 
              alt={doctor.name} 
              className="doctor-avatar" 
            />
            <div className="doctor-info">
              <h3>{doctor.name}</h3>
              <span className="last-seen">last seen {doctor.lastSeen}</span>
            </div>
          </div>

          <div className="chat-messages">
            {messages.map((msg, index) => (
              <div key={index} className={`message ${msg.sender}`}>
                <div className="message-content">
                  {msg.text}
                </div>
              </div>
            ))}
          </div>

          <form className="chat-input" onSubmit={handleSendMessage}>
            <button type="button" className="attach-btn">
              <svg viewBox="0 0 24 24">
                <path d="M19 13h-6v6h-2v-6H5v-2h6V5h2v6h6v2z"/>
              </svg>
            </button>
            <input
              type="text"
              placeholder="Type a message here..."
              value={message}
              onChange={(e) => setMessage(e.target.value)}
            />
            <button type="submit" className="send-btn">
              <svg viewBox="0 0 24 24">
                <path d="M2.01 21L23 12 2.01 3 2 10l15 2-15 2z"/>
              </svg>
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};

export default VideoCall; 