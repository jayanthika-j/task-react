import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import instapractLogo from '../../assets/images/logo.png';
import userImage from '../../assets/images/user.png';
import doctorImage from '../../assets/images/doctor.png';
import { getDoctorsList } from '../../services/api';
import './style.css';

const DoctorsList = ({ user, onLogout }) => {
  const [doctors, setDoctors] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  
  // Pagination states
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const doctorsPerPage = 10;

  const navigate = useNavigate();

  useEffect(() => {
    const fetchDoctors = async () => {
      try {
        setLoading(true);
        const response = await getDoctorsList();
        if (response.success) {
          setDoctors(response.data || []);
        } else {
          setError(response.msg || 'Failed to fetch doctors');
        }
      } catch (err) {
        setError('Error loading doctors. Please try again later.');
      } finally {
        setLoading(false);
      }
    };

    fetchDoctors();
  }, []); // Refetch when page changes

  const handlePageChange = (pageNumber) => {
    setCurrentPage(pageNumber);
    window.scrollTo(0, 0); // Scroll to top when page changes
  };

  const handleLogout = () => {
    onLogout();
  };

  const handleDoctorSelect = (doctor) => {
    navigate(`/consultation/${doctor.id}`, {
      state: { 
        doctorName: doctor.name || 'Dr. Rainer Mere',
        doctorImage: doctor.image || doctorImage,
        doctorId: doctor.id,
        lastSeen: doctor.lastSeen || '5 hours ago'
      }
    });
  };

  return (
    <div className="doctors-page">
      <nav className="nav-bar">
        <div className="nav-content">
          <div className="nav-left">
            <img src={instapractLogo} alt="InstaPract" className="nav-logo" />
          </div>
          <div className="nav-right">
            <div className="user-info">
              <div className="user-avatar">
                <img 
                  src={user?.PatientProfile?.profile_picture || userImage} 
                  alt="User"
                  onError={(e) => {
                    e.target.src = userImage; // Fallback to default image
                  }}
                />
              </div>
              <div className="user-details">
                <span className="user-name">
                  Hi, {user?.username?.split('@')[0] || 'User'}
                </span>
                <span className="user-id">
                  User ID: {user?.id || 'N/A'}
                </span>
              </div>
              <button className="logout-btn" onClick={handleLogout}>
                <svg 
                  xmlns="http://www.w3.org/2000/svg" 
                  viewBox="0 0 24 24" 
                  fill="none" 
                  stroke="currentColor" 
                  strokeWidth="2" 
                  strokeLinecap="round" 
                  strokeLinejoin="round"
                >
                  <path d="M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4"></path>
                  <polyline points="10 17 15 12 10 7"></polyline>
                  <line x1="15" y1="12" x2="3" y2="12"></line>
                </svg>
              </button>
            </div>
          </div>
        </div>
      </nav>

      <main className="main-content">
        <h1>List of Available Doctors</h1>
        
        {loading && <div className="loading">Loading doctors...</div>}
        {error && <div className="error-message">{error}</div>}
        
        <div className="doctors-list">
          {doctors.map((doctor) => (
            <div 
              key={doctor.id} 
              className="doctor-card" 
              onClick={() => handleDoctorSelect(doctor)}
            >
              <img 
                src={doctor.profile_picture}
                alt={doctor.name}
                className="doctor-avatar"
                onError={(e) => {
                  e.target.src = doctorImage; // Fallback to default image
                }}
              />
              <div className="doctor-info">
                <h3>{doctor.name}</h3>
                <p>{doctor.specialty?.map(spec => spec.name).join(', ')}</p>
                <div className="doctor-details">
                  <span>Rating: {doctor.rating || 'N/A'}</span>
                  <span>Duration: {doctor.fixed_duration} mins</span>
                  <span>Charge: ${doctor.fixed_charge}</span>
                  <span className={`status ${doctor.online_status}`}>
                    {doctor.online_status}
                  </span>
                </div>
              </div>
              <button 
                className="connect-btn"
              >
                Connect
              </button>
            </div>
          ))}
        </div>

        {/* Pagination */}
        {!loading && !error && totalPages > 1 && (
          <div className="pagination">
            <button 
              className="page-btn"
              disabled={currentPage === 1}
              onClick={() => handlePageChange(currentPage - 1)}
            >
              Previous
            </button>
            
            <div className="page-numbers">
              {[...Array(totalPages)].map((_, index) => (
                <button
                  key={index + 1}
                  className={`page-number ${currentPage === index + 1 ? 'active' : ''}`}
                  onClick={() => handlePageChange(index + 1)}
                >
                  {index + 1}
                </button>
              ))}
            </div>

            <button 
              className="page-btn"
              disabled={currentPage === totalPages}
              onClick={() => handlePageChange(currentPage + 1)}
            >
              Next
            </button>
          </div>
        )}
      </main>
    </div>
  );
};

export default DoctorsList; 