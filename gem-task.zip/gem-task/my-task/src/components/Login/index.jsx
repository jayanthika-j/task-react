import { useState } from 'react';
import { APP_CONFIG } from '../../constants/content';
import { loginUser } from '../../services/api';
import instapractLogo from '../../assets/images/logo.png';
import backgroundImage from '../../assets/images/image.png';
import SplitScreen from '../Main';
import './style.css';

const LoginPage = ({ onLoginSuccess }) => {
  const [showPassword, setShowPassword] = useState(false);
  const [formData, setFormData] = useState({
    username: localStorage.getItem('remembered_username') || '',
    password: localStorage.getItem('remembered_password') || ''
  });
  const [rememberMe, setRememberMe] = useState(!!localStorage.getItem('remembered_username'));
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleRememberMe = (e) => {
    setRememberMe(e.target.checked);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');

    // Validate empty fields first
    if (!formData.username.trim() || !formData.password.trim()) {
      setError('Please enter both username and password');
      return;
    }

    // Only set loading if validation passes
    setLoading(true);

    try {
      const response = await loginUser(formData.username, formData.password);
      
      if (response.success) {
        localStorage.setItem('accessToken', response.data.access_token);
        localStorage.setItem('user', JSON.stringify(response.data));

        if (rememberMe) {
          localStorage.setItem('remembered_username', formData.username);
          localStorage.setItem('remembered_password', formData.password);
        } else {
          localStorage.removeItem('remembered_username');
          localStorage.removeItem('remembered_password');
        }

        onLoginSuccess(response.data);
      } else {
        setError(response.msg || 'Login failed');
      }
    } catch (err) {
      setError('An error occurred. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const leftContent = (
    <>
      <div 
        className="background-image" 
        style={{
          backgroundImage: `url(${backgroundImage})`
        }}
      />
      <div className="content-wrapper">
        <h1>{APP_CONFIG.leftPanel.mainHeading}</h1>
        {APP_CONFIG.leftPanel.features.map((feature, index) => (
          <h2 key={index}>{feature}</h2>
        ))}
      </div>
    </>
  );

  const rightContent = (
    <form className="login-form" onSubmit={handleSubmit}>
      <img src={instapractLogo} alt={APP_CONFIG.company.name} className="logo" />
      <h2>Login</h2>
      
      {error && <div className="error-message">{error}</div>}
      
      <label htmlFor="username">Username</label>
      <input
        id="username"
        type="text"
        placeholder="janesmith@mymail.com"
        name="username"
        value={formData.username}
        onChange={handleInputChange}
        disabled={loading}
        className={error && !formData.username ? 'input-error' : ''}
      />
      
      <label htmlFor="password">Password</label>
      <div 
        className={`password-input-container ${showPassword ? 'show-password' : ''}`}
        onClick={() => setShowPassword(!showPassword)}
      >
        <input
          id="password"
          type={showPassword ? "text" : "password"}
          placeholder="••••••••••"
          name="password"
          value={formData.password}
          onChange={handleInputChange}
          disabled={loading}
          className={error && !formData.password ? 'input-error' : ''}
        />
      </div>
      
      <div className="remember-me">
        <input 
          type="checkbox" 
          id="remember" 
          checked={rememberMe}
          onChange={handleRememberMe}
        />
        <label htmlFor="remember">Remember me</label>
      </div>
      
      <button type="submit" disabled={loading}>
        {loading ? 'Logging in...' : 'Login'}
      </button>
    </form>
  );

  return (
    <SplitScreen
      leftContent={leftContent}
      rightContent={rightContent}
    />
  );
};

export default LoginPage; 