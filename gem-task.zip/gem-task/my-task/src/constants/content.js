export const APP_CONFIG = {
  company: {
    name: 'Instapract',
    tagline: 'HealthTech IT Solutions'
  },
  leftPanel: {
    mainHeading: 'Instapract',
    features: [
      'User Centric',
      'Teleconsulting',
      'Expert Opinion',
      'Platform.'
    ]
  },
  login: {
    title: 'Login',
    fields: {
      username: {
        placeholder: 'User Name',
        type: 'text'
      },
      password: {
        placeholder: 'Password',
        type: 'password'
      }
    },
    rememberMe: 'Remember me',
    buttonText: 'Login'
  }
};

export const BREAKPOINTS = {
  mobile: '768px',
  tablet: '1024px'
}; 