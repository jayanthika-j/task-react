import axios from 'axios';

const API_BASE_URL = 'https://qa-uaesaas-api.instapract.ae/web/api';
const DOCTORS_API_URL = 'https://ahd.instapract.ae/web/api';

const axiosInstance = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
    'Accept': 'application/json',
    'APPID': 'Gem3s12345'
  }
});

export const loginUser = async (username, password) => {
  try {
    const requestBody = {
      username,
      password,
      device_id: "55c3389cb5ddd720dc0297617f3561c43a36218a277c974c8d43d545a643f45c",
      os_id: "b93a9204-ee21-4cf9-8a94-cf5eeabf7301",
      role_id: "143f37f2-ca38-0ab1-2489-1e47113655fc",
      time_zone: "Asia/Calcutta",
      language: "da315627-3ece-2016-c628-b61dc5ee9be0"
    };

    const { data } = await axiosInstance.post('/default/login', requestBody);
    return data;
  } catch (error) {
    throw error.response?.data || error;
  }
};

export const getDoctorsList = async () => {
  try {
    // Simple POST request without any headers
    const response = await fetch(`${DOCTORS_API_URL}/doctor/doc-list`, {
      method: 'POST'
    });
    const data = await response.json();
    return data;
  } catch (error) {
    throw error;
  }
};

// Add axios interceptor for handling errors globally
axiosInstance.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      localStorage.removeItem('accessToken');
      localStorage.removeItem('user');
      window.location.href = '/login';
    }
    return Promise.reject(error);
  }
); 