import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { useState, useEffect } from 'react';
import Login from './components/Login';
import DoctorsList from './components/DoctorList';
import VideoConsultation from './components/Video';
import VideoCall from './components/VideoCall';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import './App.css';

// Protected Route Component
const ProtectedRoute = ({ children }) => {
  const token = localStorage.getItem('accessToken');
  if (!token) {
    return <Navigate to="/" replace />;
  }
  return children;
};

function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [userData, setUserData] = useState(null);

  useEffect(() => {
    // Check for existing auth on load
    const token = localStorage.getItem('accessToken');
    const user = localStorage.getItem('user');
    if (token && user) {
      setIsAuthenticated(true);
      setUserData(JSON.parse(user));
    }
  }, []);

  const handleLoginSuccess = (data) => {
    setIsAuthenticated(true);
    setUserData(data.User);
    localStorage.setItem('accessToken', data.access_token);
    localStorage.setItem('user', JSON.stringify(data.User));
    toast.success('Login successful! Welcome back!', {
      position: "top-right",
      autoClose: 3000,
      hideProgressBar: false,
      closeOnClick: true,
      pauseOnHover: true,
      draggable: true,
      style: {
        marginTop: '20px'
      }
    });
  };

  const handleLogout = () => {
    setIsAuthenticated(false);
    setUserData(null);
    localStorage.removeItem('accessToken');
    localStorage.removeItem('user');
    localStorage.removeItem('remembered_username');
    localStorage.removeItem('remembered_password');
  };

  return (
    <Router>
      <ToastContainer />
      <Routes>
        <Route 
          path="/" 
          element={
            isAuthenticated ? 
              <Navigate to="/doctors" replace /> : 
              <Login onLoginSuccess={handleLoginSuccess} />
          } 
        />
        <Route 
          path="/doctors" 
          element={
            <ProtectedRoute>
              <DoctorsList user={userData} onLogout={handleLogout} />
            </ProtectedRoute>
          } 
        />
        <Route 
          path="/consultation/:doctorId" 
          element={
            <ProtectedRoute>
              <VideoConsultation user={userData} onLogout={handleLogout} />
            </ProtectedRoute>
          } 
        />
        <Route 
          path="/video-call" 
          element={
            <ProtectedRoute>
              <VideoCall user={userData} onLogout={handleLogout} />
            </ProtectedRoute>
          } 
        />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </Router>
  );
}

export default App;
