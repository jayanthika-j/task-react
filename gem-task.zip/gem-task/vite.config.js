import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [react()],
  server: {
    proxy: {
      '/web/api': {
        target: 'https://qa-uaesaas-api.instapract.ae',
        changeOrigin: true,
        secure: false,
      }
    }
  }
}); 